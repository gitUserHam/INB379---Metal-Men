﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {

	public GameController(){

	}
	
	const int numPlayers = 2;
	int count = 0;
	public float[] score = new float[numPlayers];
	public float[] KO = new float[numPlayers];
	public float[] deaths = new float[numPlayers];
	public GameObject scrapPart;
	public GameObject[] spawnPoints;
	public GameObject[] Players;
    public Image[] healthMeter;
    public Image[] scrapUI;
    public Image[] profilePics;
    public Image[] profilePicL2;
    public Image[] hudHolder;
    float seconds = 03;
    float minutes = 5;
    public Text timerText;
    public Text gameOver;
    public Text nearlyOver;
    public Text startCountdown;
    public Image warningFlash;
    public Image clockUI;
	public Text results;
    public Image[] dangerStatus;
    public Image[] meterFull;
    Color32 barColor;

    int playerNum;


	/* Spawns a certain amount of scrap parts.
	 * 	location: Can be any game object, ie a player or spawn spot.
	 */
	public void spawnScrap (GameObject player, float amount) {
		// For each scrap required.
		for (int i = 0; i < amount; i++) {
		// Spawn the scrap pieces.
			// Set the spawn to the original game object.
			Vector2 pos = new Vector2(player.transform.position.x + 1, player.transform.position.y);
			// Spawn the scrap pieces.
			Instantiate (scrapPart, pos, transform.rotation);
		}
	}

    public void timerUpdate()
    {
        if (seconds <= 0)
        {
            seconds = 59;
            if (minutes >= 1)
            {
                minutes--;
            }
            else
            {
                minutes = 0;
                seconds = 0;
                timerText.text = minutes.ToString("f0") + ":0" + seconds.ToString("f0");
            }
        }
        else
        {
            seconds -= Time.deltaTime;
            if (minutes > 4) {
                StartCoroutine(preGameMovement(playerNum));
                timerText.enabled = false;
                startCountdown.text = seconds.ToString("f0");
                if (seconds < 1) {
                    startCountdown.text = "GO!";
                }
            } else if (minutes <= 4 && seconds <= 59){
                
                timerText.enabled = true;
                startCountdown.enabled = false;
                clockUI.transform.Rotate(0, 0, 40f * Time.deltaTime);
            }

            //During last 10 seconds
            if (minutes == 0 && seconds <= 10){
                timerText.enabled = false;                  //
                nearlyOver.text = seconds.ToString("f0");   //  Switch to warning timer text
                nearlyOver.enabled = true;                  //
                //start flashing screen for time warning
                StartCoroutine(blink(10.0f));
                clockUI.transform.Rotate(0, 0, 150f * Time.deltaTime);
                dangerStatus[playerNum].enabled = true;
            }   
        }

        if (Mathf.Round(seconds) <= 9)
        {
            timerText.text = minutes.ToString("f0") + ":0" + seconds.ToString("f0");
        }
        else
        {
            timerText.text = minutes.ToString("f0") + ":" + seconds.ToString("f0");
        }

        if (minutes == 0 && seconds == 0)
        {
			if(count == 0){
				results.text = "1st - Player" + maxScore().ToString() + System.Environment.NewLine +
								"2nd - Player" + maxScore ().ToString();
	            Destroy(GameObject.FindGameObjectWithTag("Player1"));
	            Destroy(GameObject.FindGameObjectWithTag("Player2"));
	            gameOver.enabled = true;
				results.enabled = true;
	            nearlyOver.enabled = false;
                Destroy(warningFlash);
				count++;
			}
        }
    }

    IEnumerator blink(float duration) {
        if(minutes == 0 && seconds <= 10) {
            while (duration >= 0){
            
                warningFlash.enabled = true;
                yield return new WaitForSeconds(0.2f);
                warningFlash.enabled = false;
                yield return new WaitForSeconds(0.2f);
                duration--;
            }
        }
    }

    IEnumerator meterBlink(int player){
        if (scrapUI[player].fillAmount == 0.5) {
            while (scrapUI[player].fillAmount == 0.5) {
                scrapUI[player].enabled = false;
                //profilePics[player].enabled = false;
                yield return new WaitForSeconds(0.9f);
                scrapUI[player].enabled = true;
                //profilePics[player].enabled = true;
                yield return new WaitForSeconds(0.9f);
            }
        }
    }

    IEnumerator preGameMovement(int player) {
        Players[player].GetComponent<PlayController>().enabled = false;   
        yield return new WaitForSeconds(3.0f);
        Players[player].GetComponent<PlayController>().enabled = true;   
    }

	int maxScore(){
		float maxVal = -1;
		int index = -1;
		Debug.Log (score.Length);
		for (int i = 0; i < score.Length; i++)
		{
			float thisNum = score[i];
			if (thisNum > maxVal)
			{
				maxVal = thisNum;
				index = i;
			}
		}
		score [index] = 0f;
		index++;
		Debug.Log (index);
		return index;
	}

    //Hud movements during gameplayer
    //Spin speed adjusts according to health
    //Color changes according to health
    public void hudMovement(int player, float health){
        playerNum = player;
        //float dangerZone = 25f;
        //float notSoDangerZone = 50;
        //if (health <= dangerZone) {
        //    hudHolder[player].transform.Rotate(0, 0, 150f * Time.deltaTime);
        //    healthMeter[player].color = Color.red;
        //    dangerStatus[player].enabled = true;
        //} else if (health <= notSoDangerZone && health > dangerZone){
        //    hudHolder[player].transform.Rotate(0, 0, 100f * Time.deltaTime);
        //    healthMeter[player].color = Color.yellow;
        //} else {
        //    hudHolder[player].transform.Rotate(0, 0, 50f * Time.deltaTime);
        //    healthMeter[player].color = Color.green;
        //}

        //if (minutes == 0 && seconds <= 10) {
        //    hudHolder[player].transform.Rotate(0, 0, 250f * Time.deltaTime);
        //}

        float healthPercent = health / 100;
        float greenHue = healthPercent;
        float redHue = 1 - healthPercent;
        float rotateSpeed = 50.0f + (redHue * 100);

        barColor = new Color(redHue, greenHue, 0);
        hudHolder[player].transform.Rotate(0, 0, (rotateSpeed * Time.deltaTime));
        healthMeter[player].color = barColor;
    }

    //updates the HUD by obtaining HP and Player number from PlayController
    public void updateHealth(float playerHealth, int player, int level) {
        //check if player's health exceeds 100 after leveling up
        if (level == 2 && level!= 1) {
            //scale health according to player level 2 health
            profilePics[player].enabled = false;
            profilePicL2[player].enabled = true;
            float scaledHealth;
            scaledHealth = (playerHealth / 300) + 0.5f;
            //Set health meter value to player's current health
            healthMeter[player].fillAmount = scaledHealth;
        } 
        if (level == 1 && level != 2) {
            float characterHealth;
            characterHealth = (playerHealth / 200) + 0.5f;
            healthMeter[player].fillAmount = characterHealth;
        }

    }


    //Update scrap count in HUD
    public void updateScrapUI(float scrapCount, int player) {

        float temp = scrapCount / 20; //Scale number for fill amount assignment
        scrapUI[player].fillAmount = temp;
        //indicates when meter is full
        if (temp == 0.5) {
            meterFull[player].enabled = true;
            StartCoroutine(meterBlink(player));
        } else {
            meterFull[player].enabled = false;
            StopCoroutine(meterBlink(player));
        }

    }

	public IEnumerator SpawnPlayer(int player) {
		// wait half second before respawning player
		yield return new WaitForSeconds (0.5f);

		// Get a random spawn point from the list.
		int randLoc = Random.Range(0,spawnPoints.Length);
		GameObject newPlayer = Instantiate (Players[player], spawnPoints[randLoc].transform.position, Quaternion.identity) as GameObject;

		// invulnrable for 2 seconds
		yield return new WaitForSeconds (2f);
		newPlayer.GetComponent<Rigidbody2D> ().isKinematic = false;
		foreach(Collider2D c in newPlayer.GetComponentsInChildren<Collider2D> ()) {
			c.enabled = true;
		}
        newPlayer.GetComponent<PlayController>().enabled = true;
	}
	
	
}
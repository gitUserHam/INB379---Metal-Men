﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {

	public GameController(){

	}
        
    public float[] score;
	public GameObject scrapPart;
	public GameObject[] spawnPoints;
	public GameObject[] Players;
    public Slider[] healthSlider;
    public Image[] scrapUI;
    float seconds = 59;
    float minutes = 2;
    public Text timerText;
    public Text gameOver;

	const int numPlayers = 2;

	/* Spawns a certain amount of scrap parts.
	 * 	location: Can be any game object, ie a player or spawn spot.
	 */
	public void spawnScrap (GameObject player, float amount) {
		// For each scrap required.
		for (int i = 0; i < amount; i++) {
		// Spawn the scrap pieces.
			// Set the spawn to the original game object.
			Vector2 pos = new Vector2(player.transform.position.x + 1, player.transform.position.y);
			// Spawn the scrap pieces.
			Instantiate (scrapPart, pos, transform.rotation);
			// Add temp force to make them fly off.
		}
	}

    public void timerUpdate()
    {
        if (seconds <= 0)
        {
            seconds = 59;
            if (minutes >= 1)
            {
                minutes--;
            }
            else
            {
                minutes = 0;
                seconds = 0;
                timerText.text = minutes.ToString("f0") + ":0" + seconds.ToString("f0");
            }
        }
        else
        {
            seconds -= Time.deltaTime;
        }

        if (Mathf.Round(seconds) <= 9)
        {
            timerText.text = minutes.ToString("f0") + ":0" + seconds.ToString("f0");
        }
        else
        {
            timerText.text = minutes.ToString("f0") + ":" + seconds.ToString("f0");
        }

        if (minutes == 0 && seconds == 0) {
            Destroy(GameObject.FindGameObjectWithTag("Player1"));
            Destroy(GameObject.FindGameObjectWithTag("Player2"));
            gameOver.enabled = true;
        }
    }

    //updates the HUD by obtaining HP and Player number from PlayController
    public void updateHUD(float playerHealth, int player)
    {

        //check if player's health exceeds 100 after leveling up
        if (playerHealth > 100)
        {
            //Set max value of slider bar to 150
            healthSlider[player].maxValue = 150;

            //Set slider bar value to player's current health
            healthSlider[player].value = playerHealth;

            //I was using these variables below for testing
            //P1HP = healthSlider[0].value;
            //P2HP = healthSlider[1].value;
        }
        else
        {
            healthSlider[player].maxValue = 100;
            healthSlider[player].value = playerHealth;
        }

    }

    //Update scrap count in HUD
    public void updateScrapUI(float scrapCount, int player) {
        float temp = scrapCount / 10; //Scale number for fill amount assignment

        if (temp == 1) {
            scrapUI[player].color = Color.yellow;
            scrapUI[player].fillAmount = temp;
        } else {
            scrapUI[player].color = Color.cyan;
            scrapUI[player].fillAmount = temp;
        }
    }

	public IEnumerator SpawnPlayer(int player) {
		// wait half second before respawning player
		yield return new WaitForSeconds (0.5f);

		// Get a random spawn point from the list.
		int randLoc = Random.Range(0,spawnPoints.Length);
		GameObject newPlayer = Instantiate (Players[player], spawnPoints[randLoc].transform.position, Quaternion.identity) as GameObject;

		// invulnrable for 2 seconds
		yield return new WaitForSeconds (2f);
		newPlayer.GetComponent<Rigidbody2D> ().isKinematic = false;
		foreach(Collider2D c in newPlayer.GetComponentsInChildren<Collider2D> ()) {
			c.enabled = true;
		}
        newPlayer.GetComponent<PlayController>().enabled = false;
	}
	
	
}
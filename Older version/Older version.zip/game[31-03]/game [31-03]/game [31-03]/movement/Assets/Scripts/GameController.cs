﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {

	public GameController(){

	}

	public GameObject scrapPart;
	public GameObject[] spawnPoints;
	public GameObject[] Players;

	const int numPlayers = 2;

	/* Spawns a certain amount of scrap parts.
	 * 	location: Can be any game object, ie a player or spawn spot.
	 */
	public void spawnScrap (GameObject player) {
		// For each scrap required.
		for (int i = 0; i < 1; i++) {
		// Spawn the scrap pieces.
			// Set the spawn to the original game object.
			Vector2 pos = new Vector2(player.transform.position.x + 1, player.transform.position.y);
			// Spawn the scrap pieces.
			Instantiate (scrapPart, pos, transform.rotation);
			// Add temp force to make them fly off.
		}
	}

	public IEnumerator SpawnPlayer(int player) {
		// wait half second before respawning player
		yield return new WaitForSeconds (0.5f);

		// Get a random spawn point from the list.
		int randLoc = Random.Range(0,spawnPoints.Length);
		GameObject newPlayer = Instantiate (Players[player], spawnPoints[randLoc].transform.position, Quaternion.identity) as GameObject;

		// invulnrable for 2 seconds
		yield return new WaitForSeconds (2f);
		newPlayer.GetComponent<Rigidbody2D> ().isKinematic = false;
        
		foreach(Collider2D c in newPlayer.GetComponents<Collider2D> ()) {
			c.enabled = true;
		}
	}
	
	
}
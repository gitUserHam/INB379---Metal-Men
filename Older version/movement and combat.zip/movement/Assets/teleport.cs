﻿using UnityEngine;
using System.Collections;

public class teleport : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

	void OnTriggerEnter2D(Collider2D player){
		player.transform.position = new Vector2( -(player.attachedRigidbody.position.x), player.attachedRigidbody.position.y);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

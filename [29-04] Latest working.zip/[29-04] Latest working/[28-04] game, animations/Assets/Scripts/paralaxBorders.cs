﻿using UnityEngine;
using System.Collections;

public class paralaxBorders : MonoBehaviour {
    public float speedTop = 0.4f;
    public float speedBottom = -0.4f;
    bool startMatch = false;
    public GameObject topBorder;
    public GameObject bottomBorder;
    GameController controller;
    GameObject gameControllerObject;
    
    void Start() {
        gameControllerObject = GameObject.FindWithTag("GameController");
        controller = gameControllerObject.GetComponent<GameController>();
        StartCoroutine(wait());
    }

	// Update is called once per frame
	void Update () {

        if (controller.nearlyOver.enabled == true) {
            speedTop = 5f;
            speedBottom = -5f;
        }
        
        if (startMatch) {
            topBorder.GetComponent<Renderer>().material.mainTextureOffset = new Vector2(Time.time * speedTop,0);
            bottomBorder.GetComponent<Renderer>().material.mainTextureOffset = new Vector2(Time.time * speedBottom, 0);
        }
        
    }

    IEnumerator wait() {
        yield return new WaitForSeconds(1.7f);
        startMatch = true;
    }
}
